(window.webpackJsonp=window.webpackJsonp||[]).push([[59],{1717:function(n,e,t){t(51)({target:"Number",stat:!0},{isInteger:t(563)})}}]);
//# sourceMappingURL=59.chunk.js.map