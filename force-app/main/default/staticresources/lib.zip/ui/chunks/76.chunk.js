(window.webpackJsonp=window.webpackJsonp||[]).push([[76],{1740:function(n,e,t){t(45)({target:"Number",stat:!0},{isInteger:t(558)})}}]);
//# sourceMappingURL=76.chunk.js.map