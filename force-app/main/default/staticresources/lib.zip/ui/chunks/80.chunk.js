(window.webpackJsonp=window.webpackJsonp||[]).push([[80],{1739:function(n,e,t){t(43)({target:"Number",stat:!0},{isInteger:t(533)})}}]);
//# sourceMappingURL=80.chunk.js.map